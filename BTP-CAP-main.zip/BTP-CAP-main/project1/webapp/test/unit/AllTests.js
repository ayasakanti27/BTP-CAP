sap.ui.define([
	"project1/test/unit/controller/View.controller"
], function () {
	"use strict";
});
